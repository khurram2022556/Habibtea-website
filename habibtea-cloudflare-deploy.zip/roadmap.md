# HabibTea website
- [x] Create black-and-gold design and exact-image catalogue.
- [x] Build home, collections, story, contact and legal pages.
- [x] Provide direct ordering and an honest email-draft enquiry form.
- [x] Add metadata and logo favicon; verify navigation and mobile layout.
- [x] Add supplied Energy Grape Mint photo to the energy collection.