import { createFileRoute } from '@tanstack/react-router';
import { BrandPage, Hero, QualityStrip, Collection, Editorial, Moment, Delivery, pageHead } from '@/components/habibtea';
export const Route = createFileRoute('/')({
 head: () => pageHead('HabibTea Ireland | Premium Iced Tea & Energy Drinks', 'Discover HabibTea Ireland’s premium iced teas and energy drinks. Explore distinctive flavours and enquire about delivery across Ireland.'),
 component: Index,
});
function Index() { return <BrandPage><Hero /><QualityStrip /><Collection type="tea" /><Editorial /><Collection type="energy" /><Moment /><Delivery /></BrandPage>; }
