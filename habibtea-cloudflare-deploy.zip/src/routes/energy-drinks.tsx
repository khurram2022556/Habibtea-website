import { createFileRoute } from '@tanstack/react-router';
import { BrandPage, Collection, Delivery, pageHead } from '@/components/habibtea';
export const Route = createFileRoute('/energy-drinks')({ head: () => pageHead('Energy Drink Collection | HabibTea Ireland', 'Discover HabibTea Energy in Pineapple, Classic, Zero, Double Apple and Grape Mint. Enquire about product details and availability.'), component: EnergyDrinks });
function EnergyDrinks() { return <BrandPage><Collection type="energy" full /><Delivery /></BrandPage>; }
