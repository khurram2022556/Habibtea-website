import { createFileRoute } from '@tanstack/react-router';
import { BrandPage, Collection, Delivery, pageHead } from '@/components/habibtea';
export const Route = createFileRoute('/iced-tea')({ head: () => pageHead('Iced Tea Collection | HabibTea Ireland', 'Explore HabibTea iced teas in Watermelon, Double Apple, Lemon, Peach and Grape Mint. Enquire about ordering across Ireland.'), component: IcedTea });
function IcedTea() { return <BrandPage><Collection type="tea" full /><Delivery /></BrandPage>; }
