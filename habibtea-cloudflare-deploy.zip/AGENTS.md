<!-- LOVABLE:BEGIN -->
> [!IMPORTANT]
> This project is connected to [Lovable](https://lovable.dev). Avoid rewriting
> published git history — force pushing, or rebasing/amending/squashing commits
> that are already pushed — as it rewrites history on Lovable's side and the
> user will likely lose their project history.
>
> Commits you push to the connected branch sync back to Lovable and show up in
> the editor, so keep the branch in a working state.
<!-- LOVABLE:END -->

- Keep catalogue data and reusable brand presentation in src/components/habibtea.tsx so all collection pages share the same product source of truth.
- Ordering is direct telephone or an explicitly labelled email draft; do not store enquiries or simulate sending because the business accepts email and telephone orders.
- Use imported asset pointers for supplied photographs and a separately generated empty studio backdrop so product artwork remains untouched.
