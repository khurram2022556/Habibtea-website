# HabibTea website — free Cloudflare deployment

This is a TanStack Start / React / Vite project. **Do not upload this entire source folder using the Cloudflare static-assets uploader.** Build it and deploy it as a Cloudflare Worker instead.

## 1. Install Node.js
Install the current Node.js LTS release from https://nodejs.org/ and restart your terminal.

## 2. Extract and open this project
Extract this ZIP. Open the extracted project folder in File Explorer, click the address bar, type `cmd`, and press Enter. Confirm the terminal is in the folder containing `package.json` and `wrangler.toml`.

## 3. Install dependencies and build
Run:

```bash
npm install
npm run build
```

If the build finishes successfully, continue. If it fails, save the full error message and resolve it before deploying.

## 4. Sign in to Cloudflare and deploy
Run:

```bash
npx wrangler login
npx wrangler deploy
```

Follow the browser prompt to authorize Wrangler. The deployment command uses `wrangler.toml` and publishes the built server and public assets. You may be asked to confirm installing Wrangler; accept if prompted.

Alternatively, run `npm run deploy` to build and deploy in one step.

## 5. Connect your GoDaddy domain
After deployment, open the Cloudflare dashboard and select the `habibtea-website` Worker. Open **Settings → Domains & Routes** (the exact menu wording may vary), then add your domain, such as `habibtea.ie`, and optionally `www.habibtea.ie`. Follow the DNS instructions shown by Cloudflare.

If Cloudflare asks you to move your domain's nameservers, use only the exact nameservers shown in your Cloudflare account. Before changing nameservers, copy any existing email-related DNS records (MX, SPF, DKIM and DMARC) into Cloudflare DNS so your email continues to work.

## Notes
- Cloudflare's free plan has usage limits; this setup avoids a separate paid hosting plan.
- Your domain registration at GoDaddy still needs to be renewed as usual.
- This package adds Cloudflare deployment configuration; the build must be run on your computer because dependencies were not installed in this environment.
